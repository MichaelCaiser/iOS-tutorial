# FloatingWindows
This will help you understand how  windows with elevation higher than other backgrounds can be attainable.
It has a Text based editor and a voice recorder as well.
Well its very simple to understand. You can mail for any help on cheragverma0001@gmail.com 
