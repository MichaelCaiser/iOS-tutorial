This installer will only install items under your home folder (signified by ~)

Items that will be installed:
(1) Xcode global var in ~/Library/Preferences/com.apple.Xcode.plist (which will be listed under Xcode Preferences -> Source Trees)
(2) PhoneGapLib Xcode static library project under ~/Documents/PhoneGapLib
(3) Xcode project template in ~/Library/Application Support/Developer/Shared/Xcode/Project Templates/PhoneGap

To uninstall:
(1) Remove the PHONEGAPLIB value in Xcode Preferences -> Source Trees
(2) Delete the ~/Documents/PhoneGapLib folder
(3) Delete the ~/Library/Application Support/Developer/Shared/Xcode/Project Templates/PhoneGap folder