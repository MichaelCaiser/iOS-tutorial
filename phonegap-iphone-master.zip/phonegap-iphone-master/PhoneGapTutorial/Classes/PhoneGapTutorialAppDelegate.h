//
//  PhoneGapTutorialAppDelegate.h
//  PhoneGapTutorial
//
//  Created by Jesse MacFadyen on 10-01-06.
//  Copyright Nitobi 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PhoneGapDelegate.h"

@interface PhoneGapTutorialAppDelegate : PhoneGapDelegate {
}

@end

