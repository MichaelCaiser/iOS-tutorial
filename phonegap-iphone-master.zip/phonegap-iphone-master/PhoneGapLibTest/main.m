//
//  main.m
//  PhoneGapLibTest
//
//  Created by shazron on 09-12-11.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[]) {
    
    NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, @"PhoneGapLibTestAppDelegate");
    [pool release];
    return retVal;
}
