Phonegap Javascript Plugins
=============================================================
This is where you would put your Javascript plugin code. TBD